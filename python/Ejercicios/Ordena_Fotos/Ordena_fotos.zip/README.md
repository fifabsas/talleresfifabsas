Ordenar fotos en carpetas
=========================

Este es un ejercicio cuyo proposito es mover archivos de una carpeta a otras en base a su nombre.

El [enunciado](enunciado.pdf) está subido en formato pdf.
Les dejamos un posible esqueleto del programa en [este](ordena_fotos.py) archivo.

Todos los arachivos estan zipeados en [ESTE](Ordena_fotos.zip) archivo, para que puedan descargar todo junto directamente. (para guardar el zip pueden hacer click derecho en el link al zip y luego elegir la opción "Guardar Enlace Como" o "Save Link As")
